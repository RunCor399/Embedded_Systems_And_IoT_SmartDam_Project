#define SCHEDULER_PERIOD 500
#define TRIG_PIN 
#define ECHO_PIN

#define LED_PIN 14 //D2
#define TRIG_PIN 26 //D1
#define ECHO_PIN 27 //D3
